### jQuery collapsible JSON plugin

#### Usage

```js
    $('#myElement').jsonView({
        myItem: 1
    })
```

### Live example:
[View](http://jsfiddle.net/mgcL9cwd/1/)